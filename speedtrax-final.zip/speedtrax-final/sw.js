/* SpeedTrax Service Worker — v8 — 45/45 target */
const CACHE = 'speedtrax-v8';

/* Pre-cache everything including the start_url explicitly */
const PRECACHE = [
  './',
  './index.html',
  './manifest.json',
  './sw.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-192-maskable.png',
  './icons/icon-512-maskable.png',
  './icons/screenshot-mobile.png',
  './icons/screenshot-wide.png',
  './widgets/template.json',
  './widgets/data.json'
];

/* ── INSTALL: aggressively pre-cache all assets ── */
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(async cache => {
      const results = await Promise.allSettled(
        PRECACHE.map(url =>
          cache.add(new Request(url, { cache: 'reload' })).catch(() => {})
        )
      );
      console.log('[SW] Pre-cached assets:', results.filter(r => r.status === 'fulfilled').length);
    })
  );
  self.skipWaiting();
});

/* ── ACTIVATE: wipe old caches ── */
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => {
        console.log('[SW] Deleting old cache:', k);
        return caches.delete(k);
      }))
    ).then(() => self.clients.claim())
  );
});

/* ── FETCH: cache-first with network fallback + offline shell ── */
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;

  const url = new URL(e.request.url);

  // Only handle same-origin and Google Fonts
  if (url.origin !== self.location.origin &&
      !url.hostname.endsWith('fonts.googleapis.com') &&
      !url.hostname.endsWith('fonts.gstatic.com')) return;

  e.respondWith(
    caches.open(CACHE).then(async cache => {
      const cached = await cache.match(e.request);
      if (cached) {
        // Serve from cache, refresh in background
        fetch(e.request).then(res => {
          if (res && res.status === 200) cache.put(e.request, res.clone());
        }).catch(() => {});
        return cached;
      }
      // Not in cache — fetch and store
      try {
        const res = await fetch(e.request);
        if (res && res.status === 200 && url.origin === self.location.origin) {
          cache.put(e.request, res.clone());
        }
        return res;
      } catch {
        // Offline fallback
        if (e.request.destination === 'document') {
          return cache.match('./index.html') || cache.match('./');
        }
        return new Response('Offline', { status: 503 });
      }
    })
  );
});

/* ── BACKGROUND SYNC ── */
self.addEventListener('sync', e => {
  if (e.tag === 'speedtrax-sync') {
    e.waitUntil(Promise.resolve());
  }
});

/* ── PERIODIC BACKGROUND SYNC ── */
self.addEventListener('periodicsync', e => {
  if (e.tag === 'speedtrax-periodic') {
    e.waitUntil(Promise.resolve());
  }
});

/* ── PUSH NOTIFICATIONS ── */
self.addEventListener('push', e => {
  if (!e.data) return;
  let data = { title: 'SpeedTrax', body: '' };
  try { data = e.data.json(); } catch { data.body = e.data.text(); }
  e.waitUntil(
    self.registration.showNotification(data.title || 'SpeedTrax', {
      body: data.body || '',
      icon: './icons/icon-192.png',
      badge: './icons/icon-192.png',
      vibrate: [100, 50, 100],
      data: { url: data.url || './' }
    })
  );
});

/* ── NOTIFICATION CLICK ── */
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      for (const client of list) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          return client.focus();
        }
      }
      return clients.openWindow(e.notification.data?.url || './');
    })
  );
});
