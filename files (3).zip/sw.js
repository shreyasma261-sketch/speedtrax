const CACHE = 'speedtrax-v1';
const ASSETS = [
  '/speedtrax/',
  '/speedtrax/index.html',
  '/speedtrax/manifest.json',
  '/speedtrax/icon-192.png',
  '/speedtrax/icon-512.png',
  '/speedtrax/screenshot.png'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(ASSETS.map(u => new Request(u, {cache: 'reload'}))))
      .catch(() => {})
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.open(CACHE).then(cache =>
      cache.match(e.request).then(cached => {
        if (cached) return cached;
        return fetch(e.request).then(r => {
          if (r && r.status === 200 && r.type === 'basic') cache.put(e.request, r.clone());
          return r;
        }).catch(() => cache.match('/speedtrax/'));
      })
    )
  );
});

self.addEventListener('push', e => {
  const d = e.data ? e.data.json() : {};
  e.waitUntil(self.registration.showNotification(d.title || 'SpeedTrax', {
    body: d.body || '',
    icon: '/speedtrax/icon-192.png'
  }));
});
